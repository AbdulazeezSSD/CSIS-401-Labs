package com.example.myapplication1

import android.R
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import android.widget.Toast.makeText as makeText1


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_item)


    }

        fun addChoice(view: View) {
            /*var rb1: RadioButton = radioButton
            rb1.text.toString().toDouble()  // the value of the radio button is in side , double
            var rb2: RadioButton = radioButton2
            rb2.text.toString().toDouble()  // the value of the radio button is in side , double
            var rb3: RadioButton = radioButton3
            rb3.text.toString().toDouble()  // the value of the radio button is in side , double*/
            // check if the radio button is seleceted
            //var ans1  = ((view as Button).toString().toDouble()) //radio button from string --> Double (19/49/79)
        }
        //var ans3 = ans1*ans2
        /*var ans3 = 0.0*/
        //-------------------------------------------------------------------------------------------------------------------
        var ans3: Double =0.0
        fun printbutton(view: View){
            var ans2 = pageNumber.text.toString().toDouble()

            if (radioButton1.isChecked) //check if you should use rb1 , or radioButton1 ?
            {
                ans3 = 0.19 * ans2
            }
            if (radioButton2.isChecked) {
                ans3 = 0.49 * ans2
            }
            if (radioButton3.isChecked) {
                ans3 = 0.79 * ans2
            }
            answer.text = "The order cost is $ "+ans3
        }

        }
        //-------------------------------------------------------------------------------------------------------------------

    /* var ans3 = 0.0
    if (rb1.isChecked) //check if you should use rb1 , or radioButton1 ?
    {ans3 = 0.19*ans2}
    if (rb2.isChecked)
    {ans3 = 0.49*ans2}
    if (rb3.isChecked)
    {ans3 = 0.79*ans2}
    //answer.append(ans3.toString())
    textView.text = "The order cost is $ "+ans3}*/

/*    var res = 0.0
    fun radioButtonClick(view: View) {
        val numberofprints = editTextNumber.text.toString().toDouble()
        if (view.id == R.id.radioButton) {
            Toast.makeText(this,"4 x 6 (19 cents)",Toast.LENGTH_SHORT).show()
            res = numberofprints * 0.19
        }
        if (view.id == R.id.radioButton2) {
            Toast.makeText(this,"5 x 7 (49 cents)",Toast.LENGTH_SHORT).show()
            res = numberofprints * 0.49
        }
        if (view.id == R.id.radioButton3) {
            Toast.makeText(this,"8 x 10 (79 cents)",Toast.LENGTH_SHORT).show()
            res = numberofprints * 0.79
        }
    }
    fun click(view: View) {
        textView.text = "The cost is $ " + res
    }*/


//var result = 0.0
//    }
//    fun radioButtonClick(view: View) {
//        //same as view.id == R.id.rb1

//        val num = pageNumber.text.toString().toDouble()   //first text view
//        //var result=0
//        if (view.id == R.id.r1) {
//            result=num*0.19
//        }
//        if (view.id == R.id.r2) {
//            result=num*0.49
//        }
//        if (view.id == R.id.r3) {
//            result=num*0.79
//        }
//        //answer.append(result.toString())
//            }
//fun click(view: View){
//        answer.text = "The cost is $ "+result


    /*fun addChoice(view: View) {
        var rb1 : RadioButton = radioButton1
        rb1.text.toString().toDouble()  // the value of the radio button is in side , double
        var rb2 : RadioButton = radioButton2
        rb2.text.toString().toDouble()  // the value of the radio button is in side , double
        var rb3 : RadioButton = radioButton3
        rb3.text.toString().toDouble()  // the value of the radio button is in side , double
        // check if the radio button is seleceted
        //var ans1  = ((view as Button).toString().toDouble()) //radio button from string --> Double (19/49/79)
        var ans2 = pageNumber.text.toString().toDouble()
        //var ans3 = ans1*ans2
        /*var ans3 = 0.0
        if (radioButton1.isChecked) //check if you should use rb1 , or radioButton1 ?
            {ans3 = 0.19*ans2}
        if (radioButton2.isChecked)
            {ans3 = 0.49*ans2}
        if (radioButton3.isChecked)
            {ans3 = 0.79*ans2}
            */
      var ans3 = 0.0
        if (rb1.isChecked) //check if you should use rb1 , or radioButton1 ?
        {ans3 = 0.19*ans2}
        if (rb2.isChecked)
        {ans3 = 0.49*ans2}
        if (rb3.isChecked)
        {ans3 = 0.79*ans2}
        //answer.append(ans3.toString())
        answer.text = "The order cost is $ "+ans3}
    }
/*



var result = 0.0
    }
    fun radioButtonClick(view: View) {
        //same as view.id == R.id.rb1
        val num = pageNumber.text.toString().toDouble()   //first text view
        //var result=0
        if (view.id == R.id.r1) {
            result=num*0.19
        }
        if (view.id == R.id.r2) {
            result=num*0.49
        }
        if (view.id == R.id.r3) {
            result=num*0.79
        }
        //answer.append(result.toString())
            }
fun click(view: View){
        answer.text = "The order cost is $ "+result


----------------------------------------------------------------------
        val rb1: RadioButton
        val rb2: RadioButton
        val rb3: RadioButton

        rb1 = findViewById<View>(R.id.radioButton1) as RadioButton
        rb2 = findViewById<View>(R.id.radioButton2) as RadioButton
        rb3 = findViewById<View>(R.id.radioButton3) as RadioButton

        val optionOnClickListener = View.OnClickListener { v ->
            val tv = findViewById<View>(R.id.textview) as TextView
            var str: String? = null

            // you can simply copy the string of clicked button.
            str = (v as RadioButton).text.toString()
            tv.text = str

            // to go further with check state you can manually check each radiobutton and find which one is checked.
            if (rb1.isChecked()) {
                // do something
            }
            if (rb2.isChecked()) {
                // do something
            }
            if (rb3.isChecked()) {
                // do something
            }
        }

        rb1.setOnClickListener(optionOnClickListener)
        rb2.setOnClickListener(optionOnClickListener)
        rb3.setOnClickListener(optionOnClickListener)

// check rb1 by default, if you want.

// check rb1 by default, if you want.
        rb1.setChecked(true)
        }
        */



     */